from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin

from notifications.models import Notification


class DashboardView(LoginRequiredMixin, ListView):
    """ Dashboard view """
    template_name = 'dashboard/dashboard.html'
    model = Notification
    paginate_by = 10

    def get_queryset(self, **kwargs):
        objects = self.model.objects.filter(user=self.request.user)
        return objects
