from .dashboard import DashboardView


__all__ = [
    DashboardView,
]
