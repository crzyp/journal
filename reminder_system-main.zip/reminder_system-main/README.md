# Reminder System
A django based reminder system

[![python-version](https://img.shields.io/badge/Python-3.8.10-blue)](https://www.python.org/)
[![django-version](https://img.shields.io/badge/Django-4.0.3-green)](https://www.djangoproject.com/)


