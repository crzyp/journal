from django.urls import path

from customauth import views

app_name = 'customauth'


urlpatterns = [
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('register/', views.RegisterView.as_view(), name='register'),
    path(
        'account/info/update/', views.AccountUpdateView.as_view(),
        name='update'
    ),
    path(
        'upload/image/', views.ImageUploadView.as_view(),
        name='upload_image'
    ),
    path(
        'account/delete/', views.AccountDeleteView.as_view(),
        name='account_delete'
    ),
]
