import logging
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render

from customauth.models import User

logger = logging.getLogger(__name__)


class AccountUpdateView(LoginRequiredMixin, View):
    """ Custom register view """
    template_name = 'customauth/update.html'
    model = User

    def get(self, request, *args, **kwargs):
        context = {
            'user': request.user
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        user = request.user
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        if name:
            user.profile.name = name
            user.profile.save()
        if email:
            user.email = email
            user.save()
        if password:
            user.set_password(password)
            user.save()
        context = {
            'user': user,
        }
        return render(request, self.template_name, context)
