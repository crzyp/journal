import logging
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect

from customauth.models import User

logger = logging.getLogger(__name__)


class ImageUploadView(LoginRequiredMixin, View):
    """ Custom image upload view """
    model = User

    def post(self, request, *args, **kwargs):
        user = request.user
        image = request.FILES.get('image')
        if image:
            user.profile.avatar = image
            user.profile.save()
        return redirect('dashboard:dashboard')
