import logging
from django.views.generic import View
from django.shortcuts import render, redirect

from customauth.models import User
from customauth.forms import RegisterForm

logger = logging.getLogger(__name__)


class RegisterView(View):
    """ Custom register view """
    template_name = 'customauth/register.html'
    form_class = RegisterForm

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('dashboard:dashboard')
        form = self.form_class
        context = {
            'form': form,
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('dashboard:dashboard')
        form = self.form_class(request.POST)
        message = ""
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            confirm_password = form.cleaned_data['confirm_password']
            if password == confirm_password:
                try:
                    user = User.objects.create_user(
                        email=email, password=password
                    )
                    user.profile.name = name
                    user.profile.save()
                    return redirect('customauth:login')
                except Exception as e:
                    message = f"{e}"
            else:
                message = "Password and Confirm Password did not match."
        else:
            logger.error(f'Invalid form data: {form.errors}')
            message = "Invalid email or password."
        context = {
            'form': form,
            'message': message,
        }
        return render(request, self.template_name, context)
