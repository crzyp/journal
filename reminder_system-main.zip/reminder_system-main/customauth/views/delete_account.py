import logging
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect

from customauth.models import User

logger = logging.getLogger(__name__)


class AccountDeleteView(LoginRequiredMixin, View):
    """ Custom account delete view """
    model = User

    def get(self, request, *args, **kwargs):
        user = request.user
        user.delete()
        return redirect('customauth:login')
