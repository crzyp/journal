from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler

from notifications.models import Notification, NotificationSchedule


def send_notification():
    notification_schedules = NotificationSchedule.objects.all()
    for schedule in notification_schedules:
        current_time = str(datetime.today().strftime("%H:%M"))

        print(current_time, str(schedule.first_time)[0:5])
        if current_time == str(schedule.first_time)[0:5]:
            Notification.objects.create(
                user=schedule.user,
                message=schedule.message
            )

        print(current_time, str(schedule.second_time)[0:5])
        if current_time == str(schedule.second_time)[0:5]:
            Notification.objects.create(
                user=schedule.user,
                message=schedule.message
            )

        print(current_time, str(schedule.third_time)[0:5])
        if current_time == str(schedule.third_time)[0:5]:
            Notification.objects.create(
                user=schedule.user,
                message=schedule.message
            )
    return True


def start():
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_notification, 'interval', seconds=45)
    scheduler.start()
