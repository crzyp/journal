from django.urls import path

from notifications import views

app_name = 'notifications'


urlpatterns = [
    path(
        'schedule/', views.NotificationScheduleView.as_view(), name='schedule'
    ),
    path(
        'journal-list/', views.JournalListView.as_view(), name='list'
    ),
    path(
        'journal-create/', views.JournalCreateView.as_view(), name='create'
    ),
]
