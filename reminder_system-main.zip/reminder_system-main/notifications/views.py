from django.views.generic import View, ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect

from notifications.models import NotificationSchedule, Journal
from notifications.forms import NotificationScheduleForm, JournalForm


class NotificationScheduleView(LoginRequiredMixin, View):
    template_name = 'dashboard/notification_schedule.html'
    model = NotificationSchedule
    form_class = NotificationScheduleForm

    def get(self, request, *args, **kwargs):
        try:
            schedule = NotificationSchedule.objects.get(user=request.user)
            form = self.form_class(instance=schedule)
        except NotificationSchedule.DoesNotExist:
            form = self.form_class()
        context = {
            'form': form,
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        message = ""
        try:
            schedule = NotificationSchedule.objects.get(user=request.user)
            form = self.form_class(request.POST, instance=schedule)
        except NotificationSchedule.DoesNotExist:
            form = self.form_class(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.save()
            message = "Schedule updated successfully."
        context = {
            'form': form,
            'message': message,
        }
        return render(request, self.template_name, context)


class JournalListView(LoginRequiredMixin, ListView):
    template_name = 'dashboard/journals.html'
    model = Journal
    paginate_by = 10

    def get_queryset(self, **kwargs):
        objects = self.model.objects.filter(user=self.request.user)
        return objects


class JournalCreateView(LoginRequiredMixin, View):
    template_name = 'dashboard/journal_create.html'
    model = Journal
    form_class = JournalForm

    def get(self, request, *args, **kwargs):
        form = self.form_class()
        context = {
            'form': form,
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = self.request.user
            obj.save()
            return redirect('notifications:list')
        context = {
            'form': form,
        }
        return render(request, self.template_name, context)
