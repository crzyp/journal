from django.contrib import admin

from notifications import models


@admin.register(models.Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ['id', 'text', 'created_at', 'updated_at']


@admin.register(models.NotificationSchedule)
class NotificationScheduleAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'user', 'message', 'first_time', 'second_time', 'third_time',
        'created_at', 'updated_at'
    ]


@admin.register(models.Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'message', 'created_at', 'updated_at']


@admin.register(models.Journal)
class JournalAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'name', 'created_at', 'updated_at']
