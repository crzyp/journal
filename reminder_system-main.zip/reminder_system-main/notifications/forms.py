from django import forms

from notifications.models import NotificationSchedule, Journal


class NotificationScheduleForm(forms.ModelForm):
    class Meta:
        model = NotificationSchedule
        fields = ('message', 'first_time', 'second_time', 'third_time')

        widgets = {
            'message': forms.Select(attrs={'class': 'form-control'}),
            'first_time': forms.TextInput(attrs={
                'class': 'form-control', 'type': 'time'
            }),
            'second_time': forms.TextInput(attrs={
                'class': 'form-control', 'type': 'time'
            }),
            'third_time': forms.TextInput(attrs={
                'class': 'form-control', 'type': 'time'
            }),
        }


class JournalForm(forms.ModelForm):
    class Meta:
        model = Journal
        fields = ['name']

        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
        }
