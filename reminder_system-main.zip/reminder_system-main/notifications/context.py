from notifications.models import Notification


def notification_context(request):
    if request.user.is_authenticated:
        notifications = Notification.objects.filter(user=request.user)
        total_notification = notifications.count()
        notifications_list = notifications[0:5]
    else:
        notifications_list = None
        total_notification = None
    context = {
        'total_notification': total_notification,
        'notifications': notifications_list
    }
    return context
